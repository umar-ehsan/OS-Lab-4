Lab 4 Host Dispatcher Shell Project

Group Members: <br>

Umar Ehsan <br>
100634240<br>
 <br>

Diba Shojaeigoradel<br>
100621768<br>
 <br>

Yin Zhou<br>
100314426<br>
 <br>

Thomas Jansz<br>
100642111<br>
 <br>

Objectives:<br><br>
Learn the fundamentals of signals and data structures in C<br><br>

Gain experience writing multiprocessor code and data structures<br><br>

Create a process scheduler in C<br><br><br>


Description:<br>
The lab consists of completing and submitting the entire host dispatcher shell project.



